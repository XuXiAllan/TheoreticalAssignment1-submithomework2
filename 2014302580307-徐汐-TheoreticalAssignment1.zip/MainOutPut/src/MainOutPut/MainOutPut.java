package MainOutPut;
import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
//����JXL��
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;  
import jxl.write.WritableWorkbook;  

public class MainOutPut {
	//��ʼ������
	double marksum=0.0;
	double gpasum=0.0;
	double markaveryge=0.0;
	double gpaaveryge=0.0;
	double studyscoresum=0.0;
	String markaveryges;
	String gpaaveryges;
	//����Marksline�࣬��Ҫ�Ǵ���һ�е����ݣ������Ժ����
	public class Marksline{
		Marksline(Marksline m){
			marks = m.marks;
			for(int i=0;i<9;i++){
				marksname[i] = m.marksname[i];
			}
			studyscore = m.studyscore;
			gpa = m.gpa;
		}
		Marksline() {
		}
		String[] marksname = new String[9];
		int marks;
		double studyscore;
		double gpa;
	}
	//ʹ�����ϵ������㷨
	public class ComparatorImpl implements Comparator<Marksline> {
		public int compare(Marksline s1,Marksline s2) {
			int marks1 = s1.marks;
			int marks2 = s2.marks;
			if(marks1>marks2){
				return 1;
			}else if(marks1<marks2){
				return -1;
			}else{
				return 0;
			}
		}
	}
	//����������list����ʼ��
	List<Marksline>m =new ArrayList();
	//��Ҫ����
	public void processScoreTable(File input){
		try{
			//��ʼ��
			File f = new File("ScoreSetting.xls");
			Workbook bookold =Workbook.getWorkbook(f);
			Sheet sheetold = bookold.getSheet(0);
			Cell cell =null;
			Marksline u =new Marksline();
			//��ԭ����excel������ȡ����
			for(int i=1;i<sheetold.getRows();i++){
				
				for (int j=0;j<=8;j++){
					cell = sheetold.getCell(j,i);
					u.marksname[j]=cell.getContents();
					if(j==3){
						u.studyscore=Double.parseDouble(cell.getContents());
					}
				}
				cell=sheetold.getCell(9,i);
				u.marks=Integer.parseInt(cell.getContents());
				//����GPA
				if(u.marks<60){u.gpa=0.0;}
				else if(60<=u.marks&&u.marks<64){u.gpa=1.0;}
				else if(64<=u.marks&&u.marks<68){u.gpa=1.5;}
				else if(68<=u.marks&&u.marks<72){u.gpa=2.0;}
				else if(72<=u.marks&&u.marks<75){u.gpa=2.3;}
				else if(75<=u.marks&&u.marks<78){u.gpa=2.7;}
				else if(78<=u.marks&&u.marks<82){u.gpa=3.0;}
				else if(82<=u.marks&&u.marks<85){u.gpa=3.3;}
				else if(85<=u.marks&&u.marks<90){u.gpa=3.7;}
				else if(90<=u.marks){u.gpa=4.0;}
				//�����������ݣ������Ժ����Ȩ
				gpasum +=(u.gpa*u.studyscore);
				marksum +=(u.marks*u.studyscore);
				studyscoresum +=u.studyscore;
				m.add(new Marksline(u));
			}
			//��ʼдexcel
			WritableWorkbook booknew=Workbook.createWorkbook(new File("NewScore.xls"));
			WritableSheet sheetnew = booknew.createSheet("sheet1", 0);
			//�Ƚ��㷨
			Comparator comp = new ComparatorImpl();
			Collections.sort(m, comp);
			//�����Ȩ��д��
			markaveryge=marksum/studyscoresum;
			markaveryges=String.valueOf(markaveryge);
			Label label1=new Label(10,25,markaveryges);
			sheetnew.addCell(label1);
			gpaaveryge=gpasum/studyscoresum;
			gpaaveryges=String.valueOf(gpaaveryge);
			Label label2=new Label(11,25,gpaaveryges);
			sheetnew.addCell(label2);
			//һ��һ��д��
			for(int k=0;k<m.size();k++){
				for(int l=0;l<u.marksname.length;l++){
					sheetnew.addCell(new Label(l,k,m.get(k).marksname[l]));
				}
				sheetnew.addCell(new Label(9,k,String.valueOf(m.get(k).marks)));
			}
			booknew.write();
			booknew.close();
		}
		
		catch (Exception e){
			e.printStackTrace();
		}
	}
	//Main����
	public static void main(String[] args){
		File input =new File("ScoreSetting.xls");
		MainOutPut a = new MainOutPut();
		a.processScoreTable(input);
	}
}
